package com.aura.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private val appUrl = "https://aura-tvqshg.v2.appdeploy.ai/"

    override fun onCreate(savedInstanceState: Bundle?) {
        MainActivityHolder.current = this
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(NativeBridge(this, web), "AuraNative")
        web.webViewClient = WebViewClient()
        web.loadUrl(appUrl)
        setContentView(web)
        requestBasicPermissions()
    }

    private fun requestBasicPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
    }

    fun notifyWeb(type: String, payload: String) {
        val safe = JSONObject.quote(payload)
        runOnUiThread { web.evaluateJavascript("window.auraNativeEvent && window.auraNativeEvent('$type',$safe)", null) }
    }
}

class NativeBridge(private val context: Context, private val web: WebView) {
    @JavascriptInterface fun openApp(packageName: String): String = try {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return "NOT_INSTALLED"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent); "OK"
    } catch (_: Exception) { "ERROR" }

    @JavascriptInterface fun flashlight(on: Boolean): String = try {
        val cm = context.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return "UNAVAILABLE"
        cm.setTorchMode(id, on); "OK"
    } catch (_: Exception) { "ERROR" }

    @JavascriptInterface fun volume(delta: Int): String = try {
        val am = context.getSystemService(AudioManager::class.java)
        val direction = if (delta > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        repeat(kotlin.math.abs(delta).coerceAtMost(5)) { am.adjustVolume(direction, AudioManager.FLAG_SHOW_UI) }
        "OK"
    } catch (_: Exception) { "ERROR" }

    @JavascriptInterface fun openNotificationAccess(): String = try {
        context.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "OK"
    } catch (_: Exception) { "ERROR" }

    @JavascriptInterface fun setDnd(on: Boolean): String = try {
        val nm = context.getSystemService(android.app.NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) return "ACCESS_REQUIRED"
        nm.setInterruptionFilter(if (on) android.app.NotificationManager.INTERRUPTION_FILTER_PRIORITY else android.app.NotificationManager.INTERRUPTION_FILTER_ALL)
        "OK"
    } catch (_: Exception) { "ERROR" }

    @JavascriptInterface fun openDndAccess(): String = try {
        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "OK"
    } catch (_: Exception) { "ERROR" }

    @JavascriptInterface fun startVoiceService(): String {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return "NOTIFICATION_PERMISSION_REQUIRED"
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return "MIC_PERMISSION_REQUIRED"
        return try {
            ContextCompat.startForegroundService(context, Intent(context, AuraVoiceForegroundService::class.java)); "OK"
        } catch (_: Exception) { "START_BLOCKED" }
    }

    @JavascriptInterface fun stopVoiceService(): String { context.stopService(Intent(context, AuraVoiceForegroundService::class.java)); return "OK" }
}

