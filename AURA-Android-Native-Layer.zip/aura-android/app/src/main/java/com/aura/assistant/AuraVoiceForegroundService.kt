package com.aura.assistant

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo

class AuraVoiceForegroundService : Service() {
    override fun onCreate() {
        super.onCreate()
        val channelId = "aura_assistant"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channelId, getString(com.aura.assistant.R.string.notification_channel), NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("AURA is active")
            .setContentText("Voice assistant status — listening is controlled by you")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
        ServiceCompat.startForeground(this, 42, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}
