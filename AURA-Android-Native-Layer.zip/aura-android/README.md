# AURA Android Native Layer

This Android Studio project wraps the deployed AURA UI and adds a native bridge for real device capabilities that Android permits.

## Included
- AURA WebView control surface
- JavaScript bridge (`AuraNative`)
- Open installed apps by package name
- Flashlight control
- Volume up/down
- Notification Listener awareness (inform-only)
- Foreground-service foundation for microphone mode
- Runtime microphone/notification permission requests
- Notification Access settings launcher

## Important behavior
AURA awareness never performs an action by itself. Notification events are forwarded to the UI only. Sending/replying/accepting/declining actions are not triggered by notification awareness.

## Build
Open this folder in Android Studio, sync Gradle, then run on an Android device. The Gradle wrapper is not included in this generated source package; Android Studio can import the project and provide/sync the configured Gradle tooling.

## Android restrictions
Android 12+ restricts background foreground-service starts, and Android 14+ adds microphone foreground-service type/permission checks. Start microphone mode from a visible user interaction after RECORD_AUDIO is granted. Do not attempt to bypass these restrictions.

Notification awareness requires the user to enable AURA under Android Settings > Notification Access.

Accessibility is intentionally not enabled by default. Android documents AccessibilityService primarily for accessibility use cases and it must be explicitly enabled by the user.
